﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 README (12:30am): Hello group. So i've added some things. for one, I added things at line 551-572. These fix the problem that we
 were having with having multiple header lines for the people that have more than one page of records. However, it
 broke the code that Justin wrote on line 599. I wasn't quite sure how to handle this, so I left it alone and commented out my portion. Also, as
 you can see, I've added connectivity to the database (lines 38-40 and also 110-113) and made it so that you are able to 
 sync students and their info to the dB, which I've tested and it works 100%. The code that I wrote to add the students and 
 their data to the dB starts at line 764 and ends at line 1370

 UPDATE (2:07am): I've added the functionality for the students courses and their grades for them, this also works
 100% as well.

 UPDATE (3:57am): I've added functionality to read in the current schedules and have them formatted nicely. We just need to
 get the idNumber that matches the student from the database and then use it to enter the classes the student is currently taking
 into the database with the grade "IP". Also, I'm not quite sure how to handle updating the database once there is data in it. I've been here for 12 hours
 and am exhausted and am going to bed. Goodnight! If you have any questions, feel free to text me. All of this is under the second btnCurrent click event.

 HOW TO USE: Use the first button to read in the parse file. Then, use the second button to read in the current schedules file. It may take 5-10 minutes
 for the parse file to be read in and then into the database. Everytime you run this, you need to clear the database of all updated entries. ALSO for the database
 to be updated correctly, it needs to be inside the debug folder, which is inside the bin folder, which is inside the parse folder.
 */

namespace Parse
{
    public partial class frmChooseFile : Form
    {
        // Name of the dataBase
        string dataBaseName = "project_DB_Apr27.accdb";

        // Global variables for the connection to the database
        static OleDbConnection con;
        static OleDbCommand cmd;
        static OleDbDataReader reader;

        // Declaring arrays to store the names and id's of the students
        string[] namesArray;
        string[] idArray;
        string[] concentrationArray;
        string[] yearArray;

        public frmChooseFile()
        {
            InitializeComponent();
        }
        public class Students
        {
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string idNumber { get; set; }
            public int concentrationID { get; set; }
            public string year { get; set; }
            public string CS102 { get; set; }
            public string CS102F { get; set; }
            public string CS109 { get; set; }
            public string CS110 { get; set; }
            public string CS111 { get; set; }
            public string CS170 { get; set; }
            public string CS171 { get; set; }
            public string CS205 { get; set; }
            public string CS214 { get; set; }
            public string CS221 { get; set; }
            public string CS225 { get; set; }
            public string CS226 { get; set; }
            public string CS250 { get; set; }
            public string CS255 { get; set; }
            public string CS265 { get; set; }
            public string CS270 { get; set; }
            public string CS290 { get; set; }
            public string CS292 { get; set; }
            public string CS305 { get; set; }
            public string CS310 { get; set; }
            public string CS315 { get; set; }
            public string CS321 { get; set; }
            public string CS322 { get; set; }
            public string CS325 { get; set; }
            public string CS330 { get; set; }
            public string CS350 { get; set; }
            public string CS351 { get; set; }
            public string CS355 { get; set; }
            public string CS357 { get; set; }
            public string CS358 { get; set; }
            public string CS375 { get; set; }

            //Other properties, methods, events...
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog box.
            if (result == DialogResult.OK) // Test result.
            {
                // Declarations
                string filePath = openFileDialog1.FileName; // Will be returned in form M://...etc.
                string nameIDLine = "";
                string nameLine = "";
                string idLine = "";
                int numLinesNameId = 0;
                int numLinesConcentration = 0;
                int numLinesYears = 0;

                // Connection details for the database
                con = new OleDbConnection();
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + dataBaseName;
                cmd = new OleDbCommand();
                cmd.Connection = con;

                // Setting prefixes to filter the txt files
                var coursesPrefix = new List<string> { "Report", "Birthdate", "COURSE", "Current", "End", "Page" };
                var prefixesNameID = new List<string> { "Mr.", "Mrs.", "Ms." };
                var concentrationPrefix = new List<string> { "Current" };
                var yearPrefix = new List<string> { "EHRS", "Mr.", "Mrs.", "Ms." };

                // Setting a variable to the My Documents folder
                // This can be changed
                string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);


                // Set the working label to be the only thing visible
                lblWorking.Visible = true;
                lblChoose.Visible = false;
                btnFile.Visible = false;
                lblCreated.Visible = false;
                btnCurrent.Visible = false;

                // Reads all of the lines, and filters out the lines that don't contain the prefixes listed above
                // Will eventually lead to getting the students name and their ID #
                var nameIDLines = File.ReadAllLines(filePath)
                    .Where(line => prefixesNameID.Any(prefix => line.Contains(prefix)))
                    .ToList();

                // Puts all the lines read into a single string
                var filteredAsString = string.Join(Environment.NewLine, nameIDLines);

                // Write the filtered content to a new file named "nameIDLines.txt"
                using (StreamWriter outputFile = new StreamWriter(mydocpath + @"\nameIDLines.txt"))
                {
                    outputFile.Write(filteredAsString);
                }

                // Reads all of the lines, and filters out the lines that don't contain the prefixes listed above
                // Will eventually lead to getting the students concentration and their year
                var studentConcentrations = File.ReadAllLines(filePath)
                    .Where(lines => concentrationPrefix.Any(prefix => lines.Contains(prefix)))
                    .ToList();

                // Puts all the lines read into a single string
                filteredAsString = string.Join(Environment.NewLine, studentConcentrations);

                // Write the filtered content to a new file named "concYrLines"
                using (StreamWriter output = new StreamWriter(mydocpath + @"\concentrationLines.txt"))
                {
                    output.Write(filteredAsString);
                }

                // Counts the number of lines in our name and ID file
                using (StreamReader r = new StreamReader(mydocpath + @"\nameIDLines.txt"))
                {
                    int i = 0;
                    while (r.ReadLine() != null)
                    {
                        i++;
                    }
                    numLinesNameId = i;
                }

                // Counts the number of lines in our concentration and year file
                using (StreamReader sr = new StreamReader(mydocpath + @"\concentrationLines.txt"))
                {
                    int i = 0;
                    while (sr.ReadLine() != null)
                    {
                        i++;
                    }
                    numLinesConcentration = i;
                }

                // Declaring arrays to store the names and id's of the students
                namesArray = new string[numLinesNameId];
                idArray = new string[numLinesNameId];

                // Reads each students name and id into arrays that will contain duplicates
                using (var sr = new StreamReader(mydocpath + @"\nameIDLines.txt"))
                {
                    for (int i = 0; i < numLinesNameId; i++)
                    {
                        nameIDLine = sr.ReadLine();
                        nameLine = nameIDLine.Split(new string[] { "ID" }, StringSplitOptions.None)[0];
                        idLine = nameIDLine.Split(new string[] { ": " }, StringSplitOptions.None)[1];
                        idLine = idLine.Split(new string[] { " " }, StringSplitOptions.None)[0];
                        namesArray[i] = nameLine;
                        idArray[i] = idLine;
                    }
                }

                // Takes all of the duplicates out of the namesArray and idArrays
                namesArray = namesArray.Distinct().ToArray();
                idArray = idArray.Distinct().ToArray();

                // Reads all of the lines in the file into a list
                List<string> concentrationList = new List<string>(File.ReadAllLines(mydocpath + @"\concentrationLines.txt"));

                // Figures out how many lines are in the list
                numLinesConcentration = concentrationList.Count();

                // Declares an array to store the concentrations
                concentrationArray = new string[numLinesConcentration];

                // Converts the previous list to an array
                concentrationArray = concentrationList.ToArray();

                // Looks through the array and finds the lines that contain the string "Current"
                // If so, it splits the line after the "(s): " in "Current Program(s): ", takes the
                // second half of it, and stores it into the concentration array
                for (int i = 0; i < concentrationArray.Length; i++)
                {
                    if (concentrationArray[i].Contains("Current"))
                    {
                        string[] concresult = concentrationArray[i].Split(new string[] { "(s): " }, StringSplitOptions.None);
                        if (concresult.Length > 1)
                        {
                            concentrationArray[i] = concresult[1];
                        }
                    }
                }

                // Checks to see if the element in the array contains the string "Bachelor", if so, it splits the element after
                // where it says "of Science in " and takes the second part, which will be the student's major (ex. "Cybersecurity")
                for (int i = 0; i < concentrationArray.Length; i++)
                {
                    if (concentrationArray[i].Contains("Bachelor"))
                    {
                        string[] concresult = concentrationArray[i].Split(new string[] { "of Science in " }, StringSplitOptions.None);
                        if (concresult.Length > 1)
                        {
                            concentrationArray[i] = concresult[1];
                        }
                    }
                }

                // Finds where it says the major in each line and converts it to the same string as is used in the dB
                for (int i = 0; i < concentrationArray.Length; i++)
                {
                    if (concentrationArray[i].Contains("Cybersecurity") || concentrationArray[i].Contains("cybersecurity"))
                    {
                        concentrationArray[i] = "Cybersecurity";
                    }
                    else if (concentrationArray[i].Contains("Computing & Information Science- Cis") || concentrationArray[i].Contains("computing & information science- cis"))
                    {
                        concentrationArray[i] = "Computer Science";
                    }
                    else if (concentrationArray[i].Contains("Computing & Information Science- It") || concentrationArray[i].Contains("computing & information science- it"))
                    {
                        concentrationArray[i] = "Information Technology";
                    }
                }

                // Declares an array to store the concentrations indexes
                int[] concentrationIDArray = new int[concentrationArray.Length];

                for (int i = 0; i < concentrationArray.Length; i++)
                {
                    if (concentrationArray[i] == "Computer Science")
                    {
                        concentrationIDArray[i] = 1;
                    }
                    if (concentrationArray[i] == "Cybersecurity")
                    {
                        concentrationIDArray[i] = 2;
                    }
                    if (concentrationArray[i] == "Information Technology")
                    {
                        concentrationIDArray[i] = 3;
                    }
                }

                // Reads all of the lines, and filters out the lines that don't contain the prefixes listed above
                // Will eventually lead to getting the student's year
                var studentYears = File.ReadAllLines(filePath)
                    .Where(lines => yearPrefix.Any(prefix => lines.Contains(prefix)))
                    .ToList();

                // Puts all the lines read into a single string
                filteredAsString = string.Join(Environment.NewLine, studentYears);

                // Write the filtered content to a new file named "yearsLines"
                using (StreamWriter output = new StreamWriter(mydocpath + @"\yearsLines.txt"))
                {
                    output.Write(filteredAsString);
                }

                // Reads all of the lines in the file into a list
                List<string> yearsList = new List<string>(File.ReadAllLines(mydocpath + @"\yearsLines.txt"));

                // Figures out how many lines are in the list
                numLinesYears = yearsList.Count();

                // Declares an array to store the concentrations
                string[] yearsArray = new string[numLinesYears];

                // Converts the previous list to an array
                yearsArray = yearsList.ToArray();

                // Splits every line after the "Cum" for total cumulative credits if it contains it
                for (int i = 0; i < yearsArray.Length; i++)
                {
                    if (yearsArray[i].Contains("Cum "))
                    {
                        string[] yearsResult = yearsArray[i].Split(new string[] { "Cum " }, StringSplitOptions.None);
                        if (yearsResult.Length > 1)
                        {
                            yearsArray[i] = yearsResult[1];
                        }
                    }
                }

                // If the line doesn't contain a persons name, it will split at the first space, essentially creating a format
                // that is Name, number, number, number, Name, etc.
                for (int i = 0; i < yearsArray.Length; i++)
                {
                    if (!yearsArray[i].Contains("Mr.") && !yearsArray[i].Contains("Mrs.") && !yearsArray[i].Contains("Ms."))
                    {
                        string[] yearsResult = yearsArray[i].Split('.');
                        yearsArray[i] = yearsResult[0];
                    }
                }

                List<int> cumulativeCreditsList = new List<int>();

                // this will read the lines, line by line and figure out what the total
                // number of cumulative credits is for each student.
                // The array will be in format: yearsArray[0] = "Mr. Gerald M. Abridge ID #: 0000008...", yearsArray[1] = "17.00",
                // yearsArray[2] = "Ms. Randall N. Abet ID #: 0000006...", yearsArray[3] = "62.00", yearsArray[4] = "84.00",
                // yearsArray[5] = "Ms. Randall N. Abet ID #: 0000006...", yearsArray[6] = "104.00", yearsArray[7] = "122.00", etc.
                // We need to read through the array and save the first name, which we can figure out if it's a name by checking to see
                // if the line contains "Mr. ", "Mrs. ", or "Ms. ". From there, we need to compare the number(s) between that name and
                // the next name, and then when we reach the next name, we want to check to make sure that it's not the same as the previous
                // name that we had found. If it is the same, we will keep comparing the numbers and if it isn't the same name, we will save
                // the highest number that we found to a list, cumulativeCreditsList, and
                // also overwrite the first name that we found with the second name that we have found.
                string firstName = yearsArray[0]; // We know that the first line will contain a name so we set it as the first name.
                string secondName = "";
                int firstNumber = 0;
                int secondNumber = 0;
                int highNumber = 0;

                for (int i = 1; i < yearsArray.Length; i++)
                {
                    // if the line doesn't contain a name
                    if (!yearsArray[i].Contains("Mr.") && !yearsArray[i].Contains("Mrs.") && !yearsArray[i].Contains("Ms."))
                    {
                        // convert the item in the yearsArray to an integer and set it to the first number
                        firstNumber = Int32.Parse(yearsArray[i]);
                        // the first number is the highest because it's the only one we have so far
                        if (firstNumber > highNumber)
                        {
                            highNumber = firstNumber;
                        }
                        // if the next line exists and it's not a name
                        if (i + 1 < yearsArray.Length && !yearsArray[i + 1].Contains("Mr.") && !yearsArray[i + 1].Contains("Mrs.") && !yearsArray[i + 1].Contains("Ms."))
                        {
                            // convert the next item in the yearsArray to an iteger and set it to the second number
                            secondNumber = Int32.Parse(yearsArray[i + 1]);
                        }
                        // if we reach the last line of the file, add it to the list
                        else if (!(i + 1 < yearsArray.Length))
                        {
                            // Adds the highest number of cumulative credits to the list
                            cumulativeCreditsList.Add(highNumber);

                            // Resets everything back to not much
                            highNumber = 0;
                            firstNumber = 0;
                            secondNumber = 0;
                        }
                        // if statement that's checking to see which number is the highest
                        // the only way we should change the high number is if the second number is greater than the current
                        // high number. (if they're equal, we wouldn't have to change it and if high number is already greater,
                        // we don't have to change it.
                        if (highNumber < secondNumber)
                        {
                            highNumber = secondNumber;
                        }
                    }
                    else // if the line does contain a name
                    {
                        secondName = yearsArray[i]; // the name will be our second name
                        if (secondName == firstName) // if the names are the same
                        {
                            // if the next line exists and it's not a name
                            if (i + 1 < yearsArray.Length && (!yearsArray[i + 1].Contains("Mr.") && !yearsArray[i + 1].Contains("Mrs.") && !yearsArray[i + 1].Contains("Ms.")))
                            {
                                // convert the next item in the yearsArray to an iteger and set it to the second number
                                secondNumber = Int32.Parse(yearsArray[i + 1]);
                            }
                            // if statement that's checking to see which number is the highest
                            // the only way we should change the high number is if the second number is greater than the current
                            // high number. (if they're equal, we wouldn't have to change it and if high number is already greater,
                            // we don't have to change it.
                            if (highNumber < secondNumber)
                            {
                                highNumber = secondNumber;
                            }
                        }
                        else
                        {
                            // Adds the highest number of cumulative credits to the list
                            cumulativeCreditsList.Add(highNumber);

                            // Resets everything back to not much
                            highNumber = 0;
                            firstNumber = 0;
                            secondNumber = 0;

                            // Sets the secondName to the firstName and then clears out secondName
                            firstName = secondName;
                            secondName = "";
                        }
                    }
                }

                // create a string array to store the years of each student
                yearArray = new string[cumulativeCreditsList.Count];

                // parse through the list, convert each of the numbers of credits to the corresponding year, and store
                // them into the yearArray created above
                // >=87 = Senior
                // 54-86.99 = Junior
                // 24-53.99 = Sophomore
                // <24 = Freshman
                for (int i = 0; i < cumulativeCreditsList.Count; i++)
                {
                    if (cumulativeCreditsList[i] >= 87)
                    {
                        yearArray[i] = ("Senior");
                    }
                    else if (cumulativeCreditsList[i] >= 54)
                    {
                        yearArray[i] = ("Junior");
                    }
                    else if (cumulativeCreditsList[i] >= 24)
                    {
                        yearArray[i] = ("Sophomore");
                    }
                    else
                    {
                        yearArray[i] = ("Freshman");
                    }
                }

                // Reads all of the lines, and filters out the lines that don't contain the prefixes listed above
                // Will eventually lead to getting the student's year
                var studentCourses = File.ReadAllLines(filePath)
                    .Where(lines => coursesPrefix.All(prefix => !lines.Contains(prefix)))
                    .ToList();

                // Puts all the lines read into a single string
                filteredAsString = string.Join(Environment.NewLine, studentCourses);

                // Write the filtered content to a new file named "yearsLines"
                using (StreamWriter output = new StreamWriter(mydocpath + @"\courseLines.txt"))
                {
                    output.Write(filteredAsString);
                }

                // Reads all of the lines in the file into a list
                List<string> coursesList = new List<string>(File.ReadAllLines(mydocpath + @"\courseLines.txt"));

                // Create a new list to store the names of the students and their CS classes
                // there will be other classes, but each of the CS classes will begin on a new line
                List<string> coursesAndNames = new List<string>();

                // Stores the  names of the students and their CS classes. There will be other classes, but each of the CS classes will begin on a new line
                for (int i = 0; i < coursesList.Count; i++)
                {
                    // if the line contains a name
                    if (coursesList[i].Contains("Mr.") || coursesList[i].Contains("Mrs.") || coursesList[i].Contains("Ms."))
                    {
                        coursesAndNames.Add(coursesList[i]);
                    }
                    // if the line contains the abbreviation "CS"
                    else if (coursesList[i].Contains("CS"))
                    {
                        // split the line that contains " CS" and store it in a string array
                        string[] courseResult = coursesList[i].Split(new string[] { " CS" }, StringSplitOptions.None);
                        // if the length of the string array is greater than 1, we take the second half of the line that we split above
                        // and add it to the new list that we created. Will be in the form "XXX ....." so we ad our delimiter to the front
                        if (courseResult.Length > 1)
                        {
                            for (int j = 1; j < courseResult.Length; j++)
                            {
                                if (courseResult[j].Length >= 6)
                                {
                                    coursesAndNames.Add("CS" + courseResult[j]);
                                }

                            }
                        }
                    }
                }

                // removes an item from the list if it is split and contains a colon as the 6th character in the line
                // issue when there is a "same  as..." in the parse file
                for (int i = 0; i < coursesAndNames.Count; i++)
                {
                    if (coursesAndNames[i][6] == ':')
                    {
                        coursesAndNames.RemoveAt(i);
                    }
                }

                // Create a new list that will store the grades of each student for each CS class
                List<string> grades = new List<string>();

                // Set a counter to 5 to eliminate it finding the name of the CS class that will be first on the line (ex. CS123)
                int counter = 5;

                // Parse through the list and find where the first number is after the CS class which will be the number of credits the class was (ex. 3.00)
                // After the number of credits the class was, will immediately follow a space and then the grade of the class, which is what we're looking for
                // Take the substring with length of 2 starting 5 characters further than the number of credits to acccount for the ".00 " and to account for
                // the grade either being "A" or "A-", etc. and add it to the list of grades.
                for (int i = 0; i < coursesAndNames.Count; i++)
                {
                    // if the line contains a name
                    if (coursesAndNames[i].Contains("Mr.") || coursesAndNames[i].Contains("Mrs.") || coursesAndNames[i].Contains("Ms."))
                    {
                        grades.Add(coursesAndNames[i]); // add the name to the list
                    }
                    // if the line doesn't contain a name
                    else if (!coursesAndNames[i].Contains("Mr.") && !coursesAndNames[i].Contains("Mrs.") && !coursesAndNames[i].Contains("Ms."))
                    {
                        // search through until you come across a digit
                        while (!Char.IsDigit(coursesAndNames[i][counter]))
                        {
                            counter++; // keeps track of where the digit it
                        }
                        // add course number and the grade, the course number will start at 0 and take up 5 or 6 characters.
                        //the grade will be 5 characters after the first digit found and we take in 2 characters to account for A-, etc.
                        grades.Add(coursesAndNames[i].Substring(0, 6) + coursesAndNames[i].Substring(counter + 5, 2));

                        counter = 5; // reset the counter to 5
                    }
                }
                /* HEY. so. this fixes the duplicate names problem we're having but then leads to the code failing that justin wrote on line 613
                string name = grades[0]; // setting the first name to the first line of the file (we know it's a name)
                string nextName = ""; // declaring a variable to store the value of the next name

                for (int i = 1; i < grades.Count; i++) // loop through the grades list
                {
                    if (grades[i].Length > 10) // all of the classes and their grades will be less than 10 characters, so if it's greater than 10, it'll be a name line
                    {
                        nextName = grades[i]; // get the value of the next name into nextName
                        if(name == nextName) // if the two names are the same, it's a repetition
                        {
                            grades.RemoveAt(i); // remove the second name
                            name = nextName; // set name to the second name so it's ready for the next iteration
                            nextName = ""; // set nextName back to be empty so it's ready for the next iteration
                        }
                        else // the names are different
                        {
                            name = nextName; // set name to the second name so it's ready for the next iteration
                            nextName = ""; // set nextName back to be empty so it's ready for the next iteration
                        }
                    }
                }
                */
                //declare an array of length grades
                string[] gradesArray = new string[grades.Count];

                //convert the previous List to an array
                //contains course number and grade
                gradesArray = grades.ToArray();

                // new class instance
                Students student = new Students();

                // reading through each array and assigning the correct components to each
                // namesArray, idArray, concentrationArray, and yearArray have the same length
                // which means that each element of the same number will be for the same student

                int gradesArrayStartIndex = 0;
                for (int i = 0; i < namesArray.Length; i++)
                {
                    student.firstName = namesArray[i].Split(' ')[1];
                    student.lastName = namesArray[i].Split(' ')[3];
                    student.idNumber = idArray[i];
                    student.concentrationID = concentrationIDArray[i];
                    student.year = yearArray[i];

                    int gradesArrayEndIndex = gradesArrayStartIndex; //Justin, why is this here?
                    // finds the indexes which the currents students grades are held
                    while (gradesArray[gradesArrayEndIndex + 1].Substring(0, 2) == "CS")
                    {
                        gradesArrayEndIndex++;
                    }
                    //searches for course number and if found, inputs a grade for that field in the object, else leaves null.
                    //repeats complete check after every grade input
                    for (int j = gradesArrayStartIndex + 1; j <= gradesArrayEndIndex; j++)
                    {
                        if (gradesArray[j].Substring(0, 6) == "CS102F")// no space after b/c it is the weird one
                        {
                            student.CS102F = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS102 ") //remember space after # for all others
                        {
                            student.CS102 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS109 ")
                        {
                            student.CS109 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS110 ")
                        {
                            student.CS110 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS111 ")
                        {
                            student.CS111 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS170 ")
                        {
                            student.CS170 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS171 ")
                        {
                            student.CS171 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS205 ")
                        {
                            student.CS205 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS214 ")
                        {
                            student.CS214 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS221 ")
                        {
                            student.CS221 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS225 ")
                        {
                            student.CS225 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS226 ")
                        {
                            student.CS226 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS250 ")
                        {
                            student.CS250 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS255 ")
                        {
                            student.CS255 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS265 ")
                        {
                            student.CS265 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS270 ")
                        {
                            student.CS270 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS290 ")
                        {
                            student.CS290 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS292 ")
                        {
                            student.CS292 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS305 ")
                        {
                            student.CS305 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS310 ")
                        {
                            student.CS310 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS315 ")
                        {
                            student.CS315 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS321 ")
                        {
                            student.CS321 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS322 ")
                        {
                            student.CS322 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS325 ")
                        {
                            student.CS325 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS330 ")
                        {
                            student.CS330 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS350 ")
                        {
                            student.CS350 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS351 ")
                        {
                            student.CS351 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS355 ")
                        {
                            student.CS355 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS357 ")
                        {
                            student.CS357 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS358 ")
                        {
                            student.CS358 = gradesArray[j].Substring(6, 2);
                        }

                        if (gradesArray[j].Substring(0, 6) == "CS375 ")
                        {
                            student.CS375 = gradesArray[j].Substring(6, 2);
                        }
                    }
                    gradesArrayStartIndex = gradesArrayEndIndex + 1; //checks after final grade, moves on to next student
                    
                    // Insert statement for the Students table in the database
                    cmd.CommandText = "INSERT INTO Students (firstName, lastName, idNumber, concentrationID, currentYear) VALUES ('" + student.firstName + "','" + student.lastName + "','" + student.idNumber + "','" + student.concentrationID + "','" + student.year + "')";

                    con.Open(); // Opens the connection with the database
                    int completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                    con.Close(); // Closes the connection with the database
                    if (completed > 0) // Changes the status of if the query completed or not
                    {

                        lblWorking.Text = "Success!";
                        lblCreated.Visible = true;
                        btnCurrent.Visible = true;
                    }
                    else
                    {
                        lblWorking.Text = "Failure";
                    }

                    // Inserts the student's classes and their grades into the database if they have taken the class
                    if (student.CS102F != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS102F" + "','" + student.CS102F + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS102 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS102" + "','" + student.CS102 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS109 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS109" + "','" + student.CS109 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS110 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS110" + "','" + student.CS110 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS111 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS111" + "','" + student.CS111 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS170 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS170" + "','" + student.CS170 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS171 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS171" + "','" + student.CS171 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS205 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS205" + "','" + student.CS205 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS214 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS214" + "','" + student.CS214 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS221 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS221" + "','" + student.CS221 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS225 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS225" + "','" + student.CS225 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS226 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS226" + "','" + student.CS226 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS250 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS250" + "','" + student.CS250 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS255 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS255" + "','" + student.CS255 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS265 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS265" + "','" + student.CS265 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS270 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS270" + "','" + student.CS270 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS290 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS290" + "','" + student.CS290 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS292 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS292" + "','" + student.CS292 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS305 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS305" + "','" + student.CS305 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS310 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS310" + "','" + student.CS310 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS315 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS315" + "','" + student.CS315 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS321 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS321" + "','" + student.CS321 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS322 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS322" + "','" + student.CS322 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS325 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS325" + "','" + student.CS325 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS330 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS330" + "','" + student.CS330 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS350 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS350" + "','" + student.CS350 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS351 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS351" + "','" + student.CS351 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS355 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS355" + "','" + student.CS355 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS357 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS357" + "','" + student.CS357 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS358 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS358" + "','" + student.CS358 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }

                    if (student.CS375 != null)
                    {
                        cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + student.idNumber + "','" + "CS375" + "','" + student.CS375 + "')";
                        con.Open(); // Opens the connection with the database
                        completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                        con.Close(); // Closes the connection with the database
                        if (completed > 0) // Changes the status of if the query completed or not
                        {

                            lblWorking.Text = "Success!";
                            lblCreated.Visible = true;
                            btnCurrent.Visible = true;
                        }
                        else
                        {
                            lblWorking.Text = "Failure";
                        }
                    }
                    
                }

                // Debugging Purposes Only
                // Both of these for loops can be changed, etc.
                /*for (int i = 0; i < grades.Count; i++)
                {
                    lstTest2.Items.Add(grades[i]);
                }

                for (int i = 0; i < coursesAndNames.Count; i++)
                {
                    lstTest.Items.Add(coursesAndNames[i]);
                }*/
            }
        }

        private void btnCurrent_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog box.
            if (result == DialogResult.OK) // Test result.
            {
                // Connection details for the database
                con = new OleDbConnection();
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + dataBaseName;
                cmd = new OleDbCommand();
                cmd.Connection = con;

                string filePath = openFileDialog1.FileName; // The file path that the document can be found at

                // Setting a variable to the My Documents folder
                // This can be changed/eliminated
                string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                var prefixesNameCourse = new List<string> { "Mr.", "Mrs.", "Ms.", "CS" };
                int numLinesNameCourse = 0;

                // Reads all of the lines, and filters out the lines that don't contain the prefixes listed above
                // Will eventually lead to getting the students name and their CS courses in progress
                var nameCourseLines = File.ReadAllLines(filePath)
                    .Where(line => prefixesNameCourse.Any(prefix => line.Contains(prefix)))
                    .ToList();

                // Puts all the lines read into a single string
                var filteredAsString = string.Join(Environment.NewLine, nameCourseLines);

                // Write the filtered content to a new file named "nameCourseLines.txt"
                using (StreamWriter outputFile = new StreamWriter(mydocpath + @"\nameCourseLines.txt"))
                {
                    outputFile.Write(filteredAsString);
                }

                // Counts the number of lines in our name and ID file
                using (StreamReader r = new StreamReader(mydocpath + @"\nameCourseLines.txt"))
                {
                    int i = 0;
                    while (r.ReadLine() != null)
                    {
                        i++;
                    }
                    numLinesNameCourse = i;
                }

                // Declaring a new array to store the names of students and the CS classes they're currently taking
                string[] nameCourseArray = new string[numLinesNameCourse];

                // Reads each students name and id into arrays that will contain duplicates
                using (var sr = new StreamReader(mydocpath + @"\nameCourseLines.txt"))
                {
                    for (int i = 0; i < numLinesNameCourse; i++)
                    {
                        nameCourseArray[i] = sr.ReadLine();
                    }
                }

                // Reads through the array and makes it so that the only things that you see are the name of the student and the CS classes they're taking
                for (int i = 0; i < nameCourseArray.Length; i++)
                {
                    if (nameCourseArray[i].Contains("Mr.") || nameCourseArray[i].Contains("Mrs.") || nameCourseArray[i].Contains("Ms.")) // If the line contains a name
                    {
                        // Splits the array element on every space and takes the elements in indexes 1 and 3 to make the student's name
                        nameCourseArray[i] = nameCourseArray[i].Split(' ')[0] + ' ' + nameCourseArray[i].Split(' ')[1] + ' ' + nameCourseArray[i].Split(' ')[2] + ' ' + nameCourseArray[i].Split(' ')[3];
                    }
                    else
                    {
                        // Takes in the first 6 characters of the string which will be (CS-123)
                        nameCourseArray[i] = nameCourseArray[i].Substring(0, 6);
                        // Splits the element on the '-' and combines the CS and number of the course (CS123)
                        nameCourseArray[i] = nameCourseArray[i].Split('-')[0] + nameCourseArray[i].Split('-')[1];
                    }
                    //lstTest.Items.Add(nameCourseArray[i]); // Debugging purposes only
                }

                // new class instance
                Students student = new Students();
                // for loop to read through the array, find the name of the student and then use that to get their idNumber from the database.
                // We then will have to use that idNumber to enter the classes that the student is currently taking into the Student_Courses table in the dB.
                // This is partial code currently, I just didn't have time to finish it.
                for(int i = 0; i < namesArray.Length; i++)
                {
                    string firstName = namesArray[i].Split(' ')[1];
                    string lastName = namesArray[i].Split(' ')[3];
                    for (int j = 0; j < nameCourseArray.Length; j++)
                    {
                        if (nameCourseArray[j].Length > 6)
                        {
                            if ((nameCourseArray[j] + ' ') == namesArray[i])
                            {
                                string idNumber = idArray[i];
                                int k = j + 1;
                                while (k < nameCourseArray.Length && nameCourseArray[k].Length <= 6)
                                {
                                    string className = nameCourseArray[k];
                                    cmd.CommandText = "INSERT INTO Student_Courses (studentIDNumber, courseNumber, Grades) VALUES ('" + idNumber + "','" + className + "','" + "IP" + "')";
                                    con.Open(); // Opens the connection with the database
                                    int completed = cmd.ExecuteNonQuery(); // Attempts to execute the insert query
                                    con.Close(); // Closes the connection with the database
                                    if (completed > 0) // Changes the status of if the query completed or not
                                    {

                                        lblWorking.Text = "Success!";
                                        lblCreated.Visible = true;
                                        btnCurrent.Visible = true;
                                    }
                                    else
                                    {
                                        lblWorking.Text = "Failure";
                                    }
                                    k++;
                                }
                            }
                        }
                    }
                }

            }
        }

        private void lstTest_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
