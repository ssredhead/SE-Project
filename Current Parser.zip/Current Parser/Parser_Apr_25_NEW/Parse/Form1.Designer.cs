﻿namespace Parse
{
    partial class frmChooseFile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFile = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.lblTest = new System.Windows.Forms.Label();
            this.lstTest = new System.Windows.Forms.ListBox();
            this.lblChoose = new System.Windows.Forms.Label();
            this.lblCreated = new System.Windows.Forms.Label();
            this.lstTest2 = new System.Windows.Forms.ListBox();
            this.btnCurrent = new System.Windows.Forms.Button();
            this.lblWorking = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnFile
            // 
            this.btnFile.Location = new System.Drawing.Point(142, 33);
            this.btnFile.Name = "btnFile";
            this.btnFile.Size = new System.Drawing.Size(75, 23);
            this.btnFile.TabIndex = 0;
            this.btnFile.Text = "Choose File";
            this.btnFile.UseVisualStyleBackColor = true;
            this.btnFile.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // lblTest
            // 
            this.lblTest.AutoSize = true;
            this.lblTest.Location = new System.Drawing.Point(49, 147);
            this.lblTest.Name = "lblTest";
            this.lblTest.Size = new System.Drawing.Size(244, 13);
            this.lblTest.TabIndex = 1;
            this.lblTest.Text = "This label and listbox are both solely for debugging";
            // 
            // lstTest
            // 
            this.lstTest.FormattingEnabled = true;
            this.lstTest.HorizontalScrollbar = true;
            this.lstTest.Location = new System.Drawing.Point(9, 163);
            this.lstTest.Name = "lstTest";
            this.lstTest.Size = new System.Drawing.Size(341, 160);
            this.lstTest.TabIndex = 2;
            this.lstTest.SelectedIndexChanged += new System.EventHandler(this.lstTest_SelectedIndexChanged);
            // 
            // lblChoose
            // 
            this.lblChoose.AutoSize = true;
            this.lblChoose.Location = new System.Drawing.Point(125, 17);
            this.lblChoose.Name = "lblChoose";
            this.lblChoose.Size = new System.Drawing.Size(109, 13);
            this.lblChoose.TabIndex = 3;
            this.lblChoose.Text = "Choose a file to parse";
            // 
            // lblCreated
            // 
            this.lblCreated.AutoSize = true;
            this.lblCreated.ForeColor = System.Drawing.Color.Black;
            this.lblCreated.Location = new System.Drawing.Point(66, 79);
            this.lblCreated.Name = "lblCreated";
            this.lblCreated.Size = new System.Drawing.Size(227, 13);
            this.lblCreated.TabIndex = 4;
            this.lblCreated.Text = "Now, choose the current schedule file to parse";
            this.lblCreated.Visible = false;
            // 
            // lstTest2
            // 
            this.lstTest2.FormattingEnabled = true;
            this.lstTest2.HorizontalScrollbar = true;
            this.lstTest2.Location = new System.Drawing.Point(359, 124);
            this.lstTest2.Name = "lstTest2";
            this.lstTest2.Size = new System.Drawing.Size(345, 199);
            this.lstTest2.TabIndex = 5;
            // 
            // btnCurrent
            // 
            this.btnCurrent.Location = new System.Drawing.Point(142, 95);
            this.btnCurrent.Name = "btnCurrent";
            this.btnCurrent.Size = new System.Drawing.Size(75, 23);
            this.btnCurrent.TabIndex = 6;
            this.btnCurrent.Text = "Choose File";
            this.btnCurrent.UseVisualStyleBackColor = true;
            this.btnCurrent.Visible = false;
            this.btnCurrent.Click += new System.EventHandler(this.btnCurrent_Click);
            // 
            // lblWorking
            // 
            this.lblWorking.AutoSize = true;
            this.lblWorking.Location = new System.Drawing.Point(74, 59);
            this.lblWorking.Name = "lblWorking";
            this.lblWorking.Size = new System.Drawing.Size(211, 13);
            this.lblWorking.TabIndex = 7;
            this.lblWorking.Text = "Working... This may take a couple minutes.";
            this.lblWorking.Visible = false;
            // 
            // frmChooseFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 339);
            this.Controls.Add(this.lblWorking);
            this.Controls.Add(this.btnCurrent);
            this.Controls.Add(this.lstTest2);
            this.Controls.Add(this.lblCreated);
            this.Controls.Add(this.lblChoose);
            this.Controls.Add(this.lstTest);
            this.Controls.Add(this.lblTest);
            this.Controls.Add(this.btnFile);
            this.Name = "frmChooseFile";
            this.Text = "Choose File";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFile;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label lblTest;
        private System.Windows.Forms.ListBox lstTest;
        private System.Windows.Forms.Label lblChoose;
        private System.Windows.Forms.Label lblCreated;
        private System.Windows.Forms.ListBox lstTest2;
        private System.Windows.Forms.Button btnCurrent;
        private System.Windows.Forms.Label lblWorking;
    }
}

